/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#include "Square.h"
#include <iostream>

using namespace std;

// C'tor receives color and side, throws exception if side is not valid
Square::Square(char* RGB, double s):Shape(RGB), side(s){
    if (s <= 0) {
        throw string("Exception: The side must be positive");
    }
}
// This method prints the shape with *
void Square::draw() const{
    for (int i=0;i <(int)side;i++){
        for (int j=0;j<(int)side;j++)
            cout<<"* ";
        cout<<endl;
    }
    cout<<endl;
}
// This method inserts the shape with * to ostream type object.
void Square::drawOS(ostream& os) const {
    for (int i=0;i <(int)side;i++){
        for (int j=0;j<(int)side;j++)
            os<<"* ";
        os<<endl;
    }
    os<<endl;
}
//This method inserts Squares data to ostream type object.
void Square::toOS (ostream &os) const{
    os<<"Square details: color="<< getColor() << ", side length=" << side << endl;
    os<<"area="<< getArea() << ", perimeter=" << getPerimeter() << endl;
    drawOS(os);
}
