/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#ifndef SHAPE_H
#define SHAPE_H

#include <iostream>

using namespace std;

// Shape class, Father Class of Square, OrthogonalTriangle and Circle.
class Shape{
    char* color;
public:
    // Class Methods declarations.
    Shape()=default;
    Shape(char* RGB) noexcept(false);
    virtual char* getColor() const {return color;}
    friend ostream &operator<<(ostream &os, const Shape &obj);
    virtual double getPerimeter()const=0;
    virtual double getArea()const=0;
    virtual void toOS(ostream& os) const=0;
    virtual ~Shape()=0;
};

#endif
