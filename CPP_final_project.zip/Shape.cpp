/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#include "Shape.h"
#include <iostream>
#include <cstring>

using namespace std;
// C'tor receives color, dynamically allocates memory for color field, throws exception if color is not valid
Shape::Shape(char* RGB){
    if(strcmp(RGB, "red") && strcmp(RGB, "green") && strcmp(RGB, "blue")){
        throw string("Exception: color must be red green or blue");
    }
    color = new char[strlen(RGB) + 1];
    strcpy(color,RGB);
}
// This operator prints Shape by activating Square/Triangle/Circle toOS method.
ostream &operator<<(ostream &os, const Shape& obj) {
    obj.toOS(os);
    return os;
}
// Shape destructor deletes dynamically allocated color field.
Shape::~Shape(){
    delete[] color;
}