/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#ifndef ORTHOGONALTRIANGLE_H
#define ORTHOGONALTRIANGLE_H

#include "Shape.h"
#include <cmath>

// OrthogonalTriangle class, inherits Shape publicly
class OrthogonalTriangle: public Shape {
    double side;
public:
    // Class Methods declarations.
    OrthogonalTriangle()=default;
    OrthogonalTriangle(char* RGB, double s) noexcept(false);
    void draw() const;
    void drawOS(ostream& os) const;
    virtual double getPerimeter() const {return (sqrt(2)+2)*side;}
    virtual double getArea() const {return side*side/2;}
    virtual void toOS (ostream &os) const override;
    virtual ~OrthogonalTriangle()=default;
};

#endif