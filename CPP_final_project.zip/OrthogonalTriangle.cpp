/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#include "OrthogonalTriangle.h"
#include <iostream>

using namespace std;
// C'tor receives color and side, throws exception if side is not valid
OrthogonalTriangle::OrthogonalTriangle(char* RGB, double s):Shape(RGB), side(s){
    if (s <= 0) {
        throw string("Exception: The sides must be greater then zero");
    }
}
// This method prints the shape with *
void OrthogonalTriangle::draw() const {
    for(int i=0;i <(int)side;i++){
        for (int j=0;j<i+1;j++)
            cout<<"* ";
        cout<<endl;
    }
    cout<<endl;
}
// This method inserts the shape with * to ostream type object.
void OrthogonalTriangle::drawOS(ostream& os) const {
    for(int i=0;i<(int)side;i++){
        for (int j=0;j<i+1;j++)
            os<<"* ";
        os<<endl;
    }
    os<<endl;
}
//This method inserts triangles data to ostream type object.
void OrthogonalTriangle::toOS (ostream &os) const{
    os<<"OrthogonalTriangle details: color="<< getColor() << ", side=" << side << endl;
    os<<"area="<< getArea() << ", perimeter=" << getPerimeter() << endl;
    drawOS(os);
}