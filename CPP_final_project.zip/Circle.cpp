/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#include "Circle.h"
#include <iostream>

using namespace std;
// C'tor receives color and radius, throws exception if radius is not valid
Circle::Circle(char* RGB, double r):Shape(RGB), radius(r){
    if (r <= 0) {
        throw string("Exception: The radius must be positive!");
    }
}
// This method inserts circles data to ostream type object.
void Circle::toOS (ostream &os) const{
    os<<"Circle details: color="<< getColor() << ", radius=" << radius << endl;
    os<<"area="<< getArea() << ", perimeter=" << getPerimeter() << endl;
}