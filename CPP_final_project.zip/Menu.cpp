/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#include "Menu.h"
#include "LinkedList.h"
#include "Shape.h"
#include "Square.h"
#include "OrthogonalTriangle.h"
#include "Circle.h"
#include <iostream>

using namespace std;

// Main Menu method holds LinkedList<Shape*> object. and navigate through the menu options via user input.
void Menu::mainMenu(){
    LinkedList<Shape*> LS;
    while (true) {
        cout << "=======================================\n<1> Add element to the list\n"
                "<2> Remove the last shape from list\n<3> Print the last shape\n<4> Exit\n"
                "=======================================" << endl;
        cin >> userinput;
        // This option tries to insert new Shape object to the linked list until user inputs are correct (color and side)
        if (userinput == 1) {
            bool insertSuccess = false;
            cout<<"Choose 1 for Square, 2 for Circle, 3 for Triangle:"<<endl;
            cin>>userinput;
            while(!insertSuccess){
                try{
                    if(userinput==1){
                        cout<<"Enter square's color:"<<endl;
                        cin>>colorChoice;
                        cout<<"Enter square's side length:"<<endl;
                        cin>>sideChoice;
                        Square* tempSquare = new Square(colorChoice,sideChoice);
                        LS.insert(tempSquare);
                        insertSuccess = true;
                    }
                    else if(userinput==2){
                        cout<<"Enter circle's color:"<<endl;
                        cin>>colorChoice;
                        cout<<"Enter circle's radius:"<<endl;
                        cin>>sideChoice;
                        Circle* tempCircle = new Circle(colorChoice,sideChoice);
                        LS.insert(tempCircle);
                        insertSuccess = true;
                    }
                    else if(userinput==3){
                        cout<<"Enter Triangle's color:"<<endl;
                        cin>>colorChoice;
                        cout<<"Enter Triangle's side:"<<endl;
                        cin>>sideChoice;
                        OrthogonalTriangle* tempTriangle = new OrthogonalTriangle(colorChoice,sideChoice);
                        LS.insert(tempTriangle);
                        insertSuccess = true;
                    }
                    else {
                        cout<<"Invalid choice"<<endl;
                        insertSuccess = true;
                    }
                }
                catch(string &s){
                    cout<<s<<endl;
                    cout << "please try again" << endl;
                }
            }
        }
        // This option deletes the front node and its data.
        else if (userinput == 2) {
            try{
                delete LS.deleteNode();
            }
            catch(string &s){
                cout<<s<<endl;
                cout << "please try again" << endl;
            }
        }
        // This option prints front node data.
        else if (userinput == 3) {
            try {
                cout << *LS.getTop();
            }
            catch(string &s){
                cout<<s<<endl;
            }
        }
        // This option deletes all nodes data and exit the method.
        else if (userinput == 4) {
            Node<Shape*>* temp = LS.getHead();
            while(temp){
                delete temp->getData();
                temp = temp->getNext();
            }
            cout << "Goodbye!" << endl;
            return;
        }
        else {
            cout << "Invalid selection." << endl;
        }
    }
}