/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#ifndef CIRCLE_H
#define CIRCLE_H

#include "Shape.h"
#include <cmath>

// Circle class, inherits Shape publicly
class Circle: public Shape {
    double radius;
public:
    // Class Methods declarations.
    Circle()=default;
    Circle(char* RGB, double r) noexcept(false);
    virtual double getPerimeter() const {return 2*M_PI*radius;}
    virtual double getArea() const  {return M_PI*radius*radius;}
    virtual void toOS (ostream &os) const override;
    virtual ~Circle()=default;
};

#endif
