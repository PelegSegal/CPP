/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#ifndef MENU_H
#define MENU_H

// Creating Menu Class, this class holds userinput, colorChoice and sideChoice to guide through the menu.
class Menu {
    int userinput;
    char colorChoice[200];
    double sideChoice;
public:
    // Class Methods declarations.
    inline Menu():userinput(0),colorChoice(""),sideChoice(0){}
    void mainMenu() noexcept(false);
    ~Menu()= default;
};
#endif