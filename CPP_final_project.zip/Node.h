/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#ifndef NODE_H
#define NODE_H

// Templated Node class
template <class T> class Node{
    T data;
    Node<T>* Next;
public:
    // Class Methods declarations.
    Node()=default;
    Node(T Obj):data(Obj), Next(nullptr){}
    Node(T Obj,Node<T>* N):data(Obj),Next(N){}
    Node<T>* getNext() const {return Next;}
    const T& getData() const {return data;}
    void setNext(Node<T>* N) {Next = N;}
    ~Node()=default;
};

#endif