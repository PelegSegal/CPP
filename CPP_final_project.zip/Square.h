/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#ifndef SQUARE_H
#define SQUARE_H

#include "Shape.h"

// Square class, inherits Shape publicly
class Square: public Shape {
    double side;
public:
    // Class Methods declarations.
    Square()=default;
    Square(char* RGB, double s) noexcept(false);
    void draw() const;
    void drawOS(ostream& os) const;
    virtual double getPerimeter() const {return 4*side;}
    virtual double getArea() const {return side*side;}
    virtual void toOS (ostream &os) const override;
    virtual ~Square()=default;
};

#endif