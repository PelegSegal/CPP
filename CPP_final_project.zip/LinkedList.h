/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
*/

#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "Node.h"
#include "Shape.h"
#include "Square.h"
#include "OrthogonalTriangle.h"
#include "Circle.h"
#include <iostream>

using namespace std;

template<class T> class LinkedList;

template <class T> ostream& operator<<(ostream& os, const LinkedList<T>& LS);
// Templated Linked List class
template <class T> class LinkedList{
    Node<T>* head;
public:
    // Class Methods declarations.
    LinkedList():head(nullptr){}
    void insert(const T &data);
    T deleteNode() noexcept(false);
    T deleteNode(const T &data) noexcept(false);
    bool search(const T &data) noexcept(false);
    const T& getTop() const noexcept(false);
    Node<T>* getHead() const{return head;}
    friend ostream& operator<< <T>(ostream& os, const LinkedList<T>& LS) noexcept(false);
    ~LinkedList();
};
// This method inserts new node with given data.
template <class T> void LinkedList<T>::insert(const T& data){
    if(!head){
        Node<T>* temp = new Node<T>(data);
        head = temp;
    }
    else{
        Node<T>* temp = new Node<T>(data,head);
        head = temp;
    }
}
// This method deletes front node and returns its data.
template <class T> T LinkedList<T>::deleteNode(){
    if(!head){
        throw string("Exception: The List is empty!");
    }
    else{
        T tempVal = head->getData();
        Node<T>* tempNode = head;
        head = head->getNext();
        delete tempNode;
        return tempVal;
    }
}
// This method deletes a node with the specific given data and returns its data.
template <class T> T LinkedList<T>::deleteNode(const T& data){
    if(!head){
        throw string("Exception: The List is empty!");
    }
    if(head->getData() == data){
        return deleteNode();
    }
    Node<T>* temp = head;
    while(temp->getNext()){
        if(temp->getNext()->getData() == data){
            Node<T>* del = temp->getNext();
            temp->setNext(del->getNext());
            T val = del->getData();
            delete del;
            return val;
        }
        temp = temp->getNext();
    }
    throw string("Exception: There is no such node in the list");
}
// This method checks if there is a node with the given data.
template <class T> bool LinkedList<T>::search(const T& data){
    Node<T>* temp = head;
    while(temp){
        if(temp->getData() == data){
            return true;
        }
        temp = temp->getNext();
    }
    return false;
}
// This method returns front node data.
template<class T> const T& LinkedList<T>::getTop() const{
    if(!head) {
        throw string("Exception: The List is empty!");
    }
    return head->getData();
}
// This method prints the linked list by showing the node's data in-order
template <class T> ostream& operator<<(ostream& os, const LinkedList<T>& LS){
    if(!LS.getHead()){
        os << "The List is empty!" << endl;
    }
    else{
        Node<T> *temp = LS.getHead();
        while (temp->getNext()) {
            os << temp->getData() << " -> ";
            temp = temp->getNext();
        }
        os << temp->getData() <<endl;
    }
    return os;
}
// Linked List destructor deletes all dynamically allocated nodes.
template<class T> LinkedList<T>::~LinkedList(){
    Node<T>* temp = head;
    Node<T>* del;
    while(temp){
        del = temp;
        temp = temp->getNext();
        delete del;
    }
}

#endif