/* Assignment C++: 3
   Authors: Oren Schor,  ID: 316365352
            Peleg Segal, ID: 314987520
 */

#include "Menu.h"
#include <iostream>

using namespace std;

int main() {
    //simply creating a menu instance, then calling mainMenu(). the rest is inside mainMenu().
    Menu a;
    a.mainMenu();
    return 0;
}

